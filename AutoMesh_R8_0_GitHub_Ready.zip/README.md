# AutoMesh — ANSYS Meshing 网格质量与局部细化工具

本仓库发布 **AutoMesh R8.0**，包含 Windows 可执行程序、完整源码、Python / ANSYS Worker、测试、版本记录和原始集成发布包。

## 获取与运行

- Windows x64 程序：仓库根目录 `AutoMesh.exe`。
- Go / Python 源码、Worker、测试和文档：`完整源码/`。
- R8.0 原始集成发布包：`releases/AutoMesh_R8_0_FullCandidate_ManualSizing_Integrated.zip`。
- SHA-256 校验清单：`SHA256.json`。
- 版本说明：`R8.0_候选审核与增量发布说明.md`。

请先阅读版本说明。分簇候选审核、手动选择、分批发布经过代码级与模拟测试；真实 Windows / ANSYS 2024 R2 / ACT 环境中的 Sizing 发布仍需在工程机独立验收。工具不会自动重新划网或进入 Fluent。

## 开发与测试

在 `完整源码/` 目录运行：

```powershell
go test ./...
python -m pytest -q
```

构建环境与依赖版本以源码目录中的现有项目文档为准。

## GitHub 上传

本项目对应的公开仓库为：

https://github.com/1463503175-pixel/AutoMesh

完整上传步骤见 `GITHUB_UPLOAD_GUIDE.md`。上传脚本会核验账号、公开状态、权限及远端空状态；不会强制覆盖已有提交。

## 安全与许可

公开仓库中的源码和可执行文件可被他人查看与下载。不要提交真实 ANSYS 工程、许可文件、个人凭据、访问令牌或运行时日志。仓库未附带开源许可证时，不应将其视为已授予他人任意再分发或修改的许可。
